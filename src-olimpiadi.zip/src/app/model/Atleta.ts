export interface Atleta{
    id?: number,
    nome:string,
    categoria:string,
    nazione: string,
    descrizione:string,
    sesso?:string,
    selezionato?:boolean
}